def main():
  #print('You rolled a die')

if __name__== "__main__":
  main()